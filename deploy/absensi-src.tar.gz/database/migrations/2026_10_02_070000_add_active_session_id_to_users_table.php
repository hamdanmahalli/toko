<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('active_session_id')->nullable()->after('password');
            $table->string('telepon', 30)->nullable()->after('email');
            $table->boolean('aktif')->default(true)->after('telepon');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['active_session_id', 'telepon', 'aktif']);
        });
    }
};
